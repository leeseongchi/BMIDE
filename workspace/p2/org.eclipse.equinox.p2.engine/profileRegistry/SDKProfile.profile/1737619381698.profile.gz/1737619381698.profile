<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='SDKProfile' timestamp='1737619381698'>
  <properties size='11'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\Siemens\Teamcenter2406\bmide\workspace'/>
    <property name='pgp.trustedPublicKeys' value='----BEGIN PGP PUBLIC KEY BLOCK-----&#xA;&#xA;xsFNBFhaXO0BEAC8WCdwrJNF/W+C8m9FYwAhEvKBvQ7xmoGYZqgcYe2ntT8udvgZ&#xA;k+dRwZJnu1VI3a8feOLrAmeNI2MxPP0+l2kGeC55c10duXPzLvW9oHONm39FZpCM&#xA;X1m66TYkUBeu/DIttNf5l0nv54dmm4VAWjutnVmlKGf5MVmmAH4mrkmgs7UTyQRK&#xA;JKJ8B7tAt6CI1tXq2ULjzUpz9iyD1IkWal4K2gYfooSuGLayNY+SCdcT9uZkpS4B&#xA;rnHy2QeJqPSnJv+5G1SkX1fzavWelrf72vx+su8L8QzUa6JtGJatFbAHzEdXGJ98&#xA;JnK7TAQvR3hCyzj+TnVCY1hiRO6B+4zI3j/vSJVdc5wmLejvfZRqhiaQ8Vr4xDbu&#xA;w7/i+raAKwr//zVGAqp/zN6zQmyoLks+cfuI4yqHuXKGaNs5RapKCxfukC/TRB2e&#xA;fLhqCpXAbRQ8a+R+0CCBP2WYDYNQoh4FnwuqtZefnm8NVKW+2we5y3llIrXV5PQb&#xA;FFN5WOLuNvO/JOtRQSjNd4WYttwNCDP7ATpRK6ixz7qveztGNhuiCRx01HbZ2uUE&#xA;DKV0DW8mWRjALl9/akMRcdIeTayKHDVjeNq5amnWT0vZ2F422BJW6sQryTs/NIBK&#xA;XGoVVZeXms3fzL9IpztcVFZTuwmk5kk1FXXaBDMwVHlR5hC5gIuLIfLVEwARAQAB&#xA;zTpFY2xpcHNlIFBsYXRmb3JtIFByb2plY3QgPHBsYXRmb3JtLXJlbGVuZy1kZXZA&#xA;ZWNsaXBzZS5vcmc+wsF9BBMBCAAnBQJYWlztAhsvBQkJZgGABQsJCAcDBRUKCQgL&#xA;BRYCAwEAAh4BAheAAAoJELbTq5vMZBKC8SsP/3csTQk6nxtGtQ5Q5HDBZ/5yeQe1&#xA;uVMl4DXJMxjYMRI29Uzrb+uMzP7zfs8xTBXktPB+bC5CqVE7QsnBEAMdXWvqk6pw&#xA;pmbC/felj+dyoy8FAHA+f52W94PYjci0TyDYgEeWAvtnnzJ8tMTZQT5qxhYM/Kt5&#xA;9XIrRqVCXw/kh7wlW4MF5MQAI8SK2j9W4WY9wMQbW5xfaYHo23Xi/NZ6nuYOoRKb&#xA;ejtlHXa4FSHOVYSg9sqNNnSI3mEvHrGbtlSli6ApwCSG8lcLNqjtgf2/kZncB9yg&#xA;DmTNq7ivFE9CxW6w8CGl3fpCZiT4DWXNj81P/lqpNjIwjEcbrZVbvXw5pjFKi0sJ&#xA;rpbc1ClhTKXKv+/Sn5cxMHYmzrrBoQBlLXLe+ETRZNbOpY5pSBis9ALBwXp4ARq+&#xA;YydwV1L2jntUPi3rYsR6PPnDNNfi2XNOSPF3ms5opGcR6jd+DzxzAN0Q1VTgKaHk&#xA;GpR2PqPu5RTelDObzYi28y8+URyys8JoKPpTsyJqYcJtW4X0JPgd/mRS7y53n6MQ&#xA;Quy2/yDJKomEe+Nnag16eqGDIie7RrSx82TKF9cT4Wr8qEwD22UnLEuiy02TXzsR&#xA;tWyVDCZE2mDbHbOMz0uuMqcA3WCEyZrzR1vmH7TnQ1NA9K9oxzzaayNOUw7IgE02&#xA;HNwdca2ZV+Wgurj4wsFcBBABCAAGBQJYWl1CAAoJEJ+itymfUeVDJhkQAJEHg3s+&#xA;iDs1GXoh85pcAWHdrl+PXCLz/gMAYrGvj1kKtW63atTpBvu+BnELVj7eKTUnCgRM&#xA;W2w8eKfDgQo8J6bQtHRpHnYSb7bAOKpiBgz13aZJjSvz14vabzP4zWdHtJEOmoH0&#xA;U8I0xIyFmBovelQAN9tSRaD6gWcbsAqJJPCgpn43QGSueSWuFND0Zk0rnwoc/1a8&#xA;JUKf6zEjHqBRfEVe+itvigIr9fy+xdX6fA6OE6OnBl7VZlVVKO8/EVdx3aehzHLc&#xA;WxykAVmNe2iSOW1D7UvZQvYds8f1OUHQiKc+jkA3Na/xVQ0Gwuu0L7nIi7JkAWNY&#xA;dOxPk+K9kWSa4ReXlOKjhC0hmNMtohKuZ2TSOsAqaWZtpJoPZpDOqDhOvx/lwBck&#xA;cxPSUZEJB88fdHTzR9PFD07Zh8EE+oRqVp7xauIgoTLk8wrUSnnJ4dwx+Zzp2OLB&#xA;mC0vAI+gSQXHkbG06jRDsPlXXMpS5/nEb2FhcEC3M4ytP6z+u1R2KM0c3jH9WRLB&#xA;ALqSWNM3cR5TJjUeTyN8O70s13+1tKnZNm08C0XHphxGC4SMMCaKqJ0hEqGr0WCA&#xA;qLrarSprDJ44ZFf8TcURHeKV2SuFXKUGyjgF22wAGepuKZ4whUuwBBxtDNXrpIdQ&#xA;/qAjTdr9LQcjGwZD6nH45HD+eiUaFZOlANQ8zsFNBFhaXPsBEAC3bR7f5euHbpID&#xA;DTuFYHPI0+S5X0DhuqcGBUL2HSFhWMwIlfsAaO+pt7GyfXLUkTmzugwmwO+sOW2Q&#xA;mwEZQcK2z3BrcjytZophZ9AUajbAjnadSH6UXCMmfExVVnaYSfl/+Uub42szQE/r&#xA;3gCRIz6M6clVVAjpFv4G/mumfQUV/XzLoUEYXTgwTokFJ97R+hDbHvBEBrUT8M6z&#xA;HP5DhN3EBug3qb6wZVOa/+HEX3M+7k4jVT/ppNumw0acg0DDoSNQ13VsRV6sV0XE&#xA;4zr3Zfs84f8xCgXpEMs4U6DZGqs3iJVVtbRf0oL0fgcxNgRrmbCrBfbXYfrS4u+f&#xA;J0vB+Wrflv9eNA3i6TtVL6uYpZy9uO2B1olKVzfEhsgB3QrULB4jVHZjIXGe4ILn&#xA;45ndMtAeY4M91wyobgG99Xl+1vPHrxV0+2zRP66J3puyxiKE2B7gd7hib54CB3lY&#xA;yrG1S+K1kZGCI1IFKCnqmTJXY0tKoLAASS3vtDcknXenzR5RVSpWTDuxtusekfL0&#xA;Bw8pCBoz9L4Hex8Q1j//D5CZlqcg1NKFfmBZ7ta9PTuJcpOsz/LaPG/0VHYt/QAv&#xA;5o4eeZESl7iZyM4/0NFh2s/rq0R8Z9yVSSkIvvO8d8XGZ65NTm3T4NFuEihn+AEm&#xA;+zg4KiGdYBEZvs8QQoW9e1+MMN8xnwARAQABwsOEBBgBCAAPBQJYWlz7AhsCBQkJ&#xA;ZgGAAikJELbTq5vMZBKCwV0gBBkBCAAGBQJYWlz7AAoJEHAOTzm8BTZLp0sP/0kU&#xA;dbRktaQ49o6Jy6UdMD4pQqYUugDb/Pecr5YOqxxuJyouIUNCc2cYRgsJIMRJEWio&#xA;si3xIk4oRE5BdetQKiz4crxPC7kNQBvgPrVJ0fP094ChPLf5tv1LUnGcDdUBEFXP&#xA;7huzE622dp4F3x+uZN384Y8veQJyRwLMLtr4nNYcw4u+x5UKTdDt2nSblP433btU&#xA;cTRNDEbfDBRI7ExcEgVZupQ8YHGVfqo0SxkM508ixefwMgiO2eM/cR2TyhatXh86&#xA;nr4nzYqn2/Cl9trByjknZ1Qcwav1MW0+YyGzUkYQ/dRY7WQ+2esItzzrAf/UVmQZ&#xA;XQqL+GRGo5sRc8aceEQKmDkiJBKK/WbURm2blr04nuLxSLq+03+eN5hOp8SnIIBM&#xA;TaeDE8jndbHDHPaMnMx+etTk3RzgmBMqAsKRvTdh29fzA51kohyhuOdQr3axORR3&#xA;D2So6f5x1HEcP1kAt24I+knAGsuuBCguUvbVvlqfOTssr4/jO5QczsadfZxEqXwv&#xA;vn8wQEDzMbQ/BL62U8ahUicTDh/W4cwfPjBbdPLZmG+UsKGIuAvCSfsGYDXrSSiv&#xA;o9O378jFAoR/0m5AlbMzIokhIxwNipNCzFWCkvziyVO4u7WV1WidO/EBHkw8uYUs&#xA;7LrXfqK5RZEffpoK9R1IdFIGJaH03xIu2yw3kq9HqGYQAISqS95RSMGAmqLlfOM1&#xA;O81PVVisf2hx0siboimdAZYwfAGqNm48Rht9oXHRn4oobuwlVEGZiTWkYgi8gnPe&#xA;xTKjZe6rmYZT79nL6pyhLimUa44lxA6mgtJ4D9ftqNnMEqIntaLHbBkR0itXNNlS&#xA;qvMv1WsoVS19i4kVseLr4dFMnjtesYOhJg/sl7T/IQHzflqjSyCNo5dffffAQB3K&#xA;rdaq8cz7qTW6PXM4EAFQH5uTaYJ8oDI3t7XsGyxBWX0+xVYHXXSU5Iq2CrB34Ipc&#xA;ygoXyTFOoZeXHDguPMXX2LnV+R7lNc0EeJ0oTyRSzmw0ao/5bgfiY14GfN0hvUFt&#xA;HIQ/Utlm2MUB108uOMeQ4EnM2xCiGtxjvHCc9IvS9OuR0zGpT6aSxXrrMMVC0QHA&#xA;Z+ntRHqo4mFuXrPth7+arUOW/PYmm3iLAaKqsXPhkjUrM3Ryp5v/J809tRyDmSX2&#xA;YOQQysGGkayKI2GyiilZ8MULM02MANot9m+QlOo1lLpmOUJDtzCHylg4M+kHpGPL&#xA;AW5Oi8j/f/7YH/S47HmSdgw3sHZl69WHIprKXtD8103BdNqrPJev2azwqWwxFpN8&#xA;3tEPbK4SwWPgk1nSELXZZ5ClcDgqatg+/nv7orxRAQZ+sBQdLn/Ztf0y2NKwqFh5&#xA;UNmHBQdtflW5G1L5fQggWG7V&#xA;=/Asu&#xA;-----END PGP PUBLIC KEY BLOCK-----'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\Siemens\Teamcenter2406\bmide\client'/>
    <property name='eclipse.touchpoint.launcherName' value='eclipse'/>
    <property name='org.eclipse.equinox.p2.surrogate' value='true'/>
    <property name='org.eclipse.equinox.p2.cache.shared' value='C:\Siemens\Teamcenter2406\bmide\client'/>
    <property name='org.eclipse.equinox.p2.configurationFolder' value='C:\Siemens\Teamcenter2406\bmide\workspace\config'/>
    <property name='org.eclipse.equinox.p2.launcherConfiguration' value='C:\Siemens\Teamcenter2406\bmide\workspace\config\eclipse.ini.ignored'/>
  </properties>
  <units size='5'>
    <unit id='SharedProfile_SDKProfile' version='1.0.0.1661987189817' singleton='false' generation='2'>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Shared profile'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='SharedProfile_SDKProfile' version='1.0.0.1661987189817'/>
      </provides>
      <requires size='282'>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.jar&apos;, version(&apos;2.29.0.v20220817-1401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.expressions&apos;, version(&apos;3.8.200.v20220613-1047&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help&apos;, version(&apos;3.9.100.v20210721-0601&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.win32&apos;, version(&apos;1.2.900.v20220812-1406&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.jetty&apos;, version(&apos;3.8.100.v20211021-1418&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;1.4.100.v20220620-1617&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.event&apos;, version(&apos;1.6.100.v20211021-1418&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.feature.jar&apos;, version(&apos;1.4.1700.v20220819-1949&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.doc.user&apos;, version(&apos;4.25.0.v20220830-0901&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.webapp&apos;, version(&apos;3.10.800.v20220714-2106&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.shell&apos;, version(&apos;1.1.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.identity&apos;, version(&apos;3.9.402.v20210409-2301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.di&apos;, version(&apos;1.4.0.v20210621-1133&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.variables&apos;, version(&apos;3.5.100.v20210721-1355&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.core&apos;, version(&apos;2.3.6.v20201214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.win32.x86_64&apos;, version(&apos;1.1.300.v20211021-1418&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.renderers.swt&apos;, version(&apos;0.15.600.v20220715-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.urischeme&apos;, version(&apos;1.2.100.v20211001-1648&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text.quicksearch&apos;, version(&apos;1.1.300.v20211203-1705&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.operations&apos;, version(&apos;2.6.100.v20220817-1208&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.upnp&apos;, version(&apos;1.2.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.console&apos;, version(&apos;3.11.300.v20220811-1921&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.monitoring&apos;, version(&apos;1.2.200.v20220429-1040&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.events&apos;, version(&apos;3.0.0.draft20060413_v201105210656&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare&apos;, version(&apos;3.8.500.v20220812-1406&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.scr&apos;, version(&apos;2.2.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.tukaani.xz&apos;, version(&apos;1.9.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.ssl.feature.feature.jar&apos;, version(&apos;1.1.401.v20210409-2301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.feature.group&apos;, version(&apos;2.3.1100.v20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.server&apos;, version(&apos;10.0.11&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.promise&apos;, version(&apos;1.2.0.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclient5.feature.feature.group&apos;, version(&apos;1.1.600.v20220215-0126&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources&apos;, version(&apos;3.18.0.v20220828-0546&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.registry&apos;, version(&apos;1.3.200.v20220720-2012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.ide.executable.win32.win32.x86_64.eclipse&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator.manipulator&apos;, version(&apos;2.2.0.v20210315-2228&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.position&apos;, version(&apos;1.0.1.201505202026&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.app&apos;, version(&apos;1.6.200.v20220720-2012&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher.eclipse&apos;, version(&apos;1.4.100.v20220420-1427&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper&apos;, version(&apos;1.1.700.v20220801-1124&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director.app&apos;, version(&apos;1.2.200.v20220802-0626&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata&apos;, version(&apos;2.6.300.v20220817-1208&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository.tools&apos;, version(&apos;2.3.100.v20220504-1755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.logging&apos;, version(&apos;1.2.0.v20180409-1502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf&apos;, version(&apos;3.10.0.v20210925-0032&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.client5.httpclient5&apos;, version(&apos;5.1.2.v20211217-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.jsp.jasper.registry&apos;, version(&apos;1.2.100.v20211021-1418&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;1.4.100.v20211217-1131&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.provisioning&apos;, version(&apos;1.2.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.concurrent&apos;, version(&apos;1.2.100.v20211021-1418&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.directorywatcher&apos;, version(&apos;1.3.0.v20210316-1209&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.core5.httpcore5&apos;, version(&apos;5.1.2.v20211217-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.garbagecollector&apos;, version(&apos;1.2.0.v20210316-1209&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore&apos;, version(&apos;2.28.0.v20220817-1401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.ide&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text&apos;, version(&apos;3.12.200.v20220817-1340&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.cm&apos;, version(&apos;1.6.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bouncycastle.bcpg&apos;, version(&apos;1.71.0.v20220723-1943&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.core&apos;, version(&apos;3.9.500.v20220817-1539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.commands&apos;, version(&apos;3.10.200.v20220512-0851&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.runtime&apos;, version(&apos;1.1.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.group&apos;, version(&apos;1.6.1500.v20220819-1949&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.win32.win32.x86_64&apos;, version(&apos;3.121.0.v20220829-1402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.feature.feature.group&apos;, version(&apos;3.14.1800.v20220215-0126&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime&apos;, version(&apos;3.26.0.v20220813-0916&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.compare.core&apos;, version(&apos;3.7.100.v20220812-1406&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.cheatsheets&apos;, version(&apos;3.7.400.v20220715-1705&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.themes&apos;, version(&apos;1.2.2000.v20220614-2134&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.jcraft.jsch&apos;, version(&apos;0.1.55.v20190404-1902&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi&apos;, version(&apos;3.18.100.v20220817-1601&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.ui&apos;, version(&apos;3.9.400.v20220817-1539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.search&apos;, version(&apos;3.14.200.v20220817-1340&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions.supplier&apos;, version(&apos;0.16.400.v20220613-1047&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.slf4j.api&apos;, version(&apos;1.7.30.v20200204-2150&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.registry&apos;, version(&apos;3.11.200.v20220817-1601&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.text&apos;, version(&apos;3.21.0.v20220817-1340&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt&apos;, version(&apos;0.14.600.v20220621-1327&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.jobs&apos;, version(&apos;3.13.100.v20220817-1539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt.theme&apos;, version(&apos;0.13.100.v20220310-1056&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.core&apos;, version(&apos;8.4.1.v20200122-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net.win32&apos;, version(&apos;1.0.100.v20220812-1406&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.event&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna&apos;, version(&apos;5.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.executable.win32.win32.x86_64&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.client5.httpclient5-win&apos;, version(&apos;5.1.2.v20211217-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions&apos;, version(&apos;0.17.200.v20220613-1008&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.net&apos;, version(&apos;1.4.100.v20220812-1406&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.servlet&apos;, version(&apos;10.0.11&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.css.sac&apos;, version(&apos;1.3.1.v200903091627&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.osgi.bundle.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.editors&apos;, version(&apos;3.14.400.v20220730-1844&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.externaltools&apos;, version(&apos;1.2.300.v20220618-1805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro&apos;, version(&apos;3.6.600.v20220619-1918&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.useradmin&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.application&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.base&apos;, version(&apos;4.3.800.v20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.notifications&apos;, version(&apos;0.5.0.v20220401-0716&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.rcp.feature.feature.group&apos;, version(&apos;1.4.1700.v20220819-1949&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.util.ajax&apos;, version(&apos;10.0.11&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.measurement&apos;, version(&apos;1.0.2.201802012109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin.equinox&apos;, version(&apos;1.2.200.v20220315-2155&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.util&apos;, version(&apos;3.7.100.v20220615-1601&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.feature.feature.group&apos;, version(&apos;1.6.1.v20211005-1944&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.constants&apos;, version(&apos;1.14.0.v20210324-0332&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk.scheduler&apos;, version(&apos;1.5.400.v20220805-0804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extensionlocation&apos;, version(&apos;1.4.100.v20220213-0541&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.jarprocessor&apos;, version(&apos;1.2.300.v20220420-1427&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.feature.feature.jar&apos;, version(&apos;3.14.1800.v20220215-0126&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.feature.feature.jar&apos;, version(&apos;1.6.1.v20211005-1944&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.core.refactoring&apos;, version(&apos;3.13.0.v20220822-0502&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.engine&apos;, version(&apos;2.7.500.v20220817-1208&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui&apos;, version(&apos;2.7.600.v20220817-1208&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.property&apos;, version(&apos;1.9.0.v20210619-1129&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclient5.feature.feature.jar&apos;, version(&apos;1.1.600.v20220215-0126&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench&apos;, version(&apos;1.13.200.v20220808-2019&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.jar&apos;, version(&apos;1.6.1500.v20220819-1949&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.preferences&apos;, version(&apos;3.10.100.v20220710-1223&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director&apos;, version(&apos;2.5.400.v20220817-1208&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.svg&apos;, version(&apos;1.1.0.v201011041433&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.artifact.repository&apos;, version(&apos;1.4.500.v20220420-1427&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.feature.jar&apos;, version(&apos;2.3.1100.v20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.jasper.glassfish&apos;, version(&apos;2.2.2.v201501141630&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help.ui&apos;, version(&apos;4.4.100.v20220619-1918&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.configuration&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.natives&apos;, version(&apos;1.4.400.v20220506-1821&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.browser&apos;, version(&apos;3.7.200.v20220826-1037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.common&apos;, version(&apos;3.16.200.v20220817-1601&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.metatype&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.addons.swt&apos;, version(&apos;1.4.400.v20211102-0453&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.jar&apos;, version(&apos;2.27.0.v20220817-1401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer&apos;, version(&apos;5.1.102.v20210409-2301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di&apos;, version(&apos;1.8.300.v20220817-1539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.core&apos;, version(&apos;1.4.0.v20220813-1037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator&apos;, version(&apos;3.10.300.v20220817-1444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.feature.jar&apos;, version(&apos;1.4.1700.v20220819-1949&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.eclipse&apos;, version(&apos;2.3.300.v20220817-1208&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.xml&apos;, version(&apos;1.0.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.group&apos;, version(&apos;4.25.0.v20220829-1402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.ui&apos;, version(&apos;1.4.200.v20220812-1406&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface&apos;, version(&apos;3.27.0.v20220817-1444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.common&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.console&apos;, version(&apos;1.4.500.v20211021-1418&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.resources.win32.x86_64&apos;, version(&apos;3.5.500.v20220812-1420&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.properties.tabbed&apos;, version(&apos;3.9.200.v20220717-1456&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.group&apos;, version(&apos;2.29.0.v20220817-1401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatesite&apos;, version(&apos;1.2.300.v20220420-1427&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.externaltools&apos;, version(&apos;3.5.200.v20220618-1805&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.bindings&apos;, version(&apos;0.13.100.v20210722-1426&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.group&apos;, version(&apos;4.25.0.v20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.p2.reconciler.dropins&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.genericeditor&apos;, version(&apos;1.2.200.v20211217-1247&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.beans&apos;, version(&apos;1.8.0.v20210619-1111&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.team.genericeditor.diff.extension&apos;, version(&apos;1.1.100.v20220812-1406&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.device&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.ibm.icu&apos;, version(&apos;67.1.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench3&apos;, version(&apos;0.16.0.v20210619-0956&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ltk.ui.refactoring&apos;, version(&apos;3.12.200.v20220808-2221&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change&apos;, version(&apos;2.14.0.v20190528-0725&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views&apos;, version(&apos;3.11.200.v20220817-1444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-io&apos;, version(&apos;2.11.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.widgets&apos;, version(&apos;1.3.0.v20210621-1136&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient5.win32&apos;, version(&apos;1.0.400.v20220109-1926&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.ssl.feature.feature.group&apos;, version(&apos;1.1.401.v20210409-2301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.feature.jar&apos;, version(&apos;2.4.1700.v20220819-1949&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.model.workbench&apos;, version(&apos;2.2.200.v20220817-1444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatechecker&apos;, version(&apos;1.3.0.v20210315-2228&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.jxpath&apos;, version(&apos;1.3.0.v200911051830&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.services&apos;, version(&apos;2.3.300.v20220613-1047&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.ssl&apos;, version(&apos;1.2.401.v20210409-2301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp&apos;, version(&apos;4.25.0.v20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views.log&apos;, version(&apos;1.3.300.v20220717-1456&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net.win32.x86_64&apos;, version(&apos;1.1.700.v20220812-1406&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench.texteditor&apos;, version(&apos;3.16.600.v20220809-1658&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.jar&apos;, version(&apos;4.25.0.v20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher&apos;, version(&apos;1.6.400.v20210924-0641&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.prefs&apos;, version(&apos;1.1.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.feature.jar&apos;, version(&apos;4.25.0.v20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator.resources&apos;, version(&apos;3.8.400.v20220203-1803&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench&apos;, version(&apos;3.126.0.v20220823-0718&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.universal&apos;, version(&apos;3.4.300.v20220619-1918&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.bidi&apos;, version(&apos;1.4.200.v20220710-1223&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.annotations&apos;, version(&apos;1.7.200.v20220613-1008&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.component&apos;, version(&apos;1.5.0.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analyzers-smartcn&apos;, version(&apos;8.4.1.v20200122-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filebuffers&apos;, version(&apos;3.7.200.v20220202-1008&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository&apos;, version(&apos;2.6.200.v20220819-1949&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.jar&apos;, version(&apos;4.25.0.v20220829-1402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ant.core&apos;, version(&apos;3.6.500.v20220718-1722&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common&apos;, version(&apos;2.26.0.v20220817-1401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.http&apos;, version(&apos;10.0.11&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.contexts&apos;, version(&apos;1.11.0.v20220716-0839&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem&apos;, version(&apos;1.9.500.v20220817-1539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher&apos;, version(&apos;1.7.200.v20220805-0804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem.win32.x86_64&apos;, version(&apos;1.4.300.v20220812-1420&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.codec&apos;, version(&apos;1.14.0.v20200818-1422&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.services&apos;, version(&apos;3.11.0.v20220618-0838&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt&apos;, version(&apos;3.121.0.v20220829-1402&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.commands&apos;, version(&apos;1.0.200.v20220629-1225&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.update.configurator&apos;, version(&apos;3.4.900.v20220718-1722&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css&apos;, version(&apos;1.14.0.v20210324-0332&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.databinding&apos;, version(&apos;1.13.0.v20210619-1146&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer&apos;, version(&apos;3.2.800.v20220215-0126&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding&apos;, version(&apos;1.11.100.v20220817-1444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui&apos;, version(&apos;3.201.100.v20220826-1037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.core&apos;, version(&apos;0.13.300.v20220809-1237&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.transport.ecf&apos;, version(&apos;1.3.300.v20220512-1321&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform&apos;, version(&apos;4.25.0.v20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.ide&apos;, version(&apos;3.16.100.v20220310-1350&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.intro.quicklinks&apos;, version(&apos;1.1.200.v20220619-1918&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.ssl&apos;, version(&apos;1.0.201.v20210409-2301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.feature.group&apos;, version(&apos;4.25.0.v20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.wireadmin&apos;, version(&apos;1.0.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;a.jre.javase&apos;, version(&apos;19.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core&apos;, version(&apos;2.9.200.v20220817-1208&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.http.servlet&apos;, version(&apos;1.7.300.v20220726-1300&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extras.feature.feature.group&apos;, version(&apos;1.4.1700.v20220819-1949&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.swt.win32&apos;, version(&apos;1.1.0.v20201119-1132&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.apache.felix.scr&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin&apos;, version(&apos;2.2.100.v20220817-1208&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform.ide.executable.win32.win32.x86_64&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.annotation&apos;, version(&apos;1.3.5.v20200909-1856&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.config.win32.win32.x86_64&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.security&apos;, version(&apos;10.0.11&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.compatibility.state&apos;, version(&apos;1.2.700.v20220722-0431&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.ssl.feature.feature.jar&apos;, version(&apos;1.1.501.v20210409-2301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk&apos;, version(&apos;1.2.100.v20220814-1551&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net&apos;, version(&apos;1.4.0.v20220813-1037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.io&apos;, version(&apos;10.0.11&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.dialogs&apos;, version(&apos;1.3.300.v20220815-1831&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher.win32.win32.x86_64&apos;, version(&apos;1.2.600.v20220720-1916&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.el&apos;, version(&apos;2.2.0.v201303151357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.console&apos;, version(&apos;1.2.0.v20210315-2042&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.w3c.dom.smil&apos;, version(&apos;1.0.1.v200903091627&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.el&apos;, version(&apos;2.2.0.v201303151357&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.platform_root&apos;, version(&apos;4.25.0.v20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.bouncycastle.bcprov&apos;, version(&apos;1.71.0.v20220723-1943&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.emf.xpath&apos;, version(&apos;0.3.0.v20210722-1426&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide&apos;, version(&apos;3.19.100.v20220820-0412&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide.application&apos;, version(&apos;1.4.500.v20220623-0641&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.core.runtime&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.swt&apos;, version(&apos;0.16.600.v20220607-1204&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata.repository&apos;, version(&apos;1.4.100.v20220329-1456&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.observable&apos;, version(&apos;1.12.0.v20211231-1006&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.i18n&apos;, version(&apos;1.14.0.v20210324-0332&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingwin32.win32.x86_64org.eclipse.equinox.event&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.win32&apos;, version(&apos;3.4.400.v20200414-1247&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.group&apos;, version(&apos;2.27.0.v20220817-1401&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher&apos;, version(&apos;1.6.400.v20210924-0641&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna.platform&apos;, version(&apos;5.8.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.lucene.analyzers-common&apos;, version(&apos;8.4.1.v20200122-1459&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.forms&apos;, version(&apos;3.11.400.v20220817-1444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.inject&apos;, version(&apos;1.0.0.v20220405-0441&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.ant&apos;, version(&apos;1.10.12.v20211102-1452&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.source.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher.win32.win32.x86_64&apos;, version(&apos;1.2.600.v20220720-1916&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp_root&apos;, version(&apos;4.25.0.v20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.user.ui.feature.group&apos;, version(&apos;2.4.1700.v20220819-1949&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.util&apos;, version(&apos;10.0.11&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;javax.servlet.jsp-api&apos;, version(&apos;2.3.3&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.ui.launchview&apos;, version(&apos;1.0.300.v20220811-0741&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security&apos;, version(&apos;1.3.1000.v20220801-1135&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xmi&apos;, version(&apos;2.17.0.v20220817-1334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util&apos;, version(&apos;1.14.0.v20210324-0332&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.function&apos;, version(&apos;1.2.0.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.pb&apos;, version(&apos;2.3.6.v20201214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.command&apos;, version(&apos;1.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xmlgraphics&apos;, version(&apos;2.6.0.v20210409-0748&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.servlet-api&apos;, version(&apos;4.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.progress&apos;, version(&apos;0.3.500.v20220717-1456&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.core5.httpcore5-h2&apos;, version(&apos;5.1.2.v20211217-1500&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient5&apos;, version(&apos;1.0.300.v20220215-0126&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.ssl.feature.feature.group&apos;, version(&apos;1.1.501.v20210409-2301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.services&apos;, version(&apos;1.5.0.v20210115-1333&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.ide.ini.win32.win32.x86_64&apos;, version(&apos;4.25.0.I20220831-1800&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.core&apos;, version(&apos;3.20.0.v20220811-0741&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.importexport&apos;, version(&apos;1.3.300.v20220329-1456&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.platform.configuration&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.contenttype&apos;, version(&apos;3.8.200.v20220817-1539&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.debug.ui&apos;, version(&apos;3.17.0.v20220817-1312&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.ui&apos;, version(&apos;1.3.300.v20220710-1223&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.org.eclipse.update.feature.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='org.eclipse.platform.ide' version='4.25.0.I20220831-1800'>
      <update id='org.eclipse.platform.ide' range='[4.0.0,4.25.0.I20220831-1800)' severity='0' description='An update for 4.x generation Eclipse Platform.'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Eclipse Platform'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='org.eclipse.equinox.p2.description' value='4.25 Release of the Eclipse Platform.'/>
        <property name='org.eclipse.equinox.p2.provider' value='Eclipse.org'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.ide' version='4.25.0.I20220831-1800'/>
      </provides>
      <requires size='10'>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.group' range='[2.4.1700.v20220819-1949,2.4.1700.v20220819-1949]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.application' range='[4.25.0.I20220831-1800,4.25.0.I20220831-1800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' range='[4.25.0.v20220831-1800,4.25.0.v20220831-1800]'/>
        <required namespace='osgi.ee' name='JavaSE' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.configuration.macosx' range='[1.0.0,1.0.0]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.configuration' range='[1.0.0,1.0.0]'>
          <filter>
            (!(osgi.os=macosx))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.configuration' range='[4.25.0.I20220831-1800,4.25.0.I20220831-1800]'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='configure'>
            addRepository(type:0,location:https${#58}//download.eclipse.org/eclipse/updates/4.25,name:The Eclipse Project Updates);addRepository(type:1,location:https${#58}//download.eclipse.org/eclipse/updates/4.25,name:The Eclipse Project Updates);addRepository(type:0,location:https${#58}//download.eclipse.org/releases/2022-09,name:2022-09);addRepository(type:1,location:https${#58}//download.eclipse.org/releases/2022-09,name:2022-09);mkdir(path:${installFolder}/dropins);
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='http://eclipse.org/legal/epl/notice.php' url='http://eclipse.org/legal/epl/notice.php'>
          Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;    delivering, extending, and upgrading the Content. Typical modules may&#xA;    include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;    features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;    (Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;    associated material. Each Feature may be packaged as a sub-directory in a&#xA;    directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;    contain a list of the names and version numbers of the Plug-ins and/or&#xA;    Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;    Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;    version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;    http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;    http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;    http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;    http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;    http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;    http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;    execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;    intent of installing, extending or updating the functionality of an&#xA;    Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;    party Installable Software or a portion thereof to be accessed and copied to&#xA;    the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;    conditions that govern the use of the Installable Software (&quot;Installable&#xA;    Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;    accessed from the Target Machine in accordance with the Specification. Such&#xA;    Installable Software Agreement must inform the user of the terms and&#xA;    conditions that govern the Installable Software and must solicit acceptance&#xA;    by the end user in the manner prescribed in such Installable&#xA;    Software Agreement. Upon such indication of agreement by the user, the&#xA;    provisioning Technology will complete installation of the&#xA;    Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.
        </license>
      </licenses>
    </unit>
    <unit id='org.eclipse.platform.ide.executable.win32.win32.x86_64' version='4.25.0.I20220831-1800'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.ide.executable.win32.win32.x86_64' version='4.25.0.I20220831-1800'/>
        <provided namespace='toolingorg.eclipse.platform.ide' name='org.eclipse.platform.ide.executable' version='4.25.0.I20220831-1800'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.platform.ide.executable.win32.win32.x86_64' version='4.25.0.I20220831-1800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='org.eclipse.platform_root' version='4.25.0.v20220831-1800'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform_root' version='4.25.0.v20220831-1800'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.platform_root' version='4.25.0.v20220831-1800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp_root' version='4.25.0.v20220831-1800'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp_root' version='4.25.0.v20220831-1800'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rcp_root' version='4.25.0.v20220831-1800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='5'>
    <iuProperties id='SharedProfile_SDKProfile' version='1.0.0.1661987189817'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform.ide' version='4.25.0.I20220831-1800'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform.ide.executable.win32.win32.x86_64' version='4.25.0.I20220831-1800'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/jenkins/agent/workspace/I-build-4.25/eclipse.platform.releng.aggregator/eclipse.platform.releng.aggregator/cje-production/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/eclipse.platform.repository/target/products/org.eclipse.platform.ide/win32/win32/x86_64/eclipse' value='/home/jenkins/agent/workspace/I-build-4.25/eclipse.platform.releng.aggregator/eclipse.platform.releng.aggregator/cje-production/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/eclipse.platform.repository/target/products/org.eclipse.platform.ide/win32/win32/x86_64/eclipse/eclipse.exe|/home/jenkins/agent/workspace/I-build-4.25/eclipse.platform.releng.aggregator/eclipse.platform.releng.aggregator/cje-production/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/eclipse.platform.repository/target/products/org.eclipse.platform.ide/win32/win32/x86_64/eclipse/eclipsec.exe|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform_root' version='4.25.0.v20220831-1800'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/jenkins/agent/workspace/I-build-4.25/eclipse.platform.releng.aggregator/eclipse.platform.releng.aggregator/cje-production/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/eclipse.platform.repository/target/products/org.eclipse.platform.ide/win32/win32/x86_64/eclipse' value='/home/jenkins/agent/workspace/I-build-4.25/eclipse.platform.releng.aggregator/eclipse.platform.releng.aggregator/cje-production/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/eclipse.platform.repository/target/products/org.eclipse.platform.ide/win32/win32/x86_64/eclipse/.eclipseproduct|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp_root' version='4.25.0.v20220831-1800'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/jenkins/agent/workspace/I-build-4.25/eclipse.platform.releng.aggregator/eclipse.platform.releng.aggregator/cje-production/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/eclipse.platform.repository/target/products/org.eclipse.platform.ide/win32/win32/x86_64/eclipse' value='/home/jenkins/agent/workspace/I-build-4.25/eclipse.platform.releng.aggregator/eclipse.platform.releng.aggregator/cje-production/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/eclipse.platform.repository/target/products/org.eclipse.platform.ide/win32/win32/x86_64/eclipse/readme|/home/jenkins/agent/workspace/I-build-4.25/eclipse.platform.releng.aggregator/eclipse.platform.releng.aggregator/cje-production/gitCache/eclipse.platform.releng.aggregator/eclipse.platform.releng.tychoeclipsebuilder/eclipse.platform.repository/target/products/org.eclipse.platform.ide/win32/win32/x86_64/eclipse/readme/readme_eclipse.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
